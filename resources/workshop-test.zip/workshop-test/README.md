# workshop-test

This folder is used to verify your setup before the workshop.
If you can see this file in Obsidian, you're on the right track.
