---
name: memory-loop
description: Use after completing significant work, before moving on to the next task. Closes the memory loop by updating decisions, learning logs, and other project files so the system remembers what happened.
---

# Memory Loop

After significant work, before moving on — check if anything needs to be remembered.

## Checklist

- New insight? → Check your agent's learning log in `brain/learning-logs/` (e.g., `learning-log-writer.md`). If the insight is already captured, skip. Otherwise, add it.
- Noteworthy decision? → Check `brain/decisions.md` first — if it's already there, skip. Otherwise, add it.
- Project scope/goals changed? → Update `core/project-brief.md` (rare)
- User preferences changed? → Update `core/user-identity.md` (rare)
- Brand voice evolved? → Update `core/tone-of-voice.md` (rare)
- Produced something reusable? → Save in `brain/artifacts/`

If nothing changed — skip. Don't force it.

## Learning Log Entry Format

- What worked that we should repeat?
- What failed that we should avoid?
- Any pattern emerging?

## Decision Entry Format

- What was decided?
- Why?
- What alternatives were rejected, and why?
