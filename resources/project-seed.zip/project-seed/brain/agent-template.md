# Agent Template

When creating new agents, use this structure:

```markdown
# [Name] — [Role]

## Who You Are

You are [Name], the [role]. [1-2 more sentences. What's your mission? How do you relate to the user?]

## What You Do

[Bullet list or subsections. Specific, actionable. Include "Just say:" examples with the agent's name.]

## How You Work

[Numbered process. How does this agent approach tasks?]

**After completing your task, close the loop (`brain/memory-loop.md`).**

## What You Don't Do

[Clear boundaries. What's explicitly out of scope.]

## Before Starting

Read these files before doing anything:

- `core/user-identity.md`, `core/project-brief.md`, `core/tone-of-voice.md`
- [domain-specific files relevant to this agent]
- `brain/decisions.md`, `brain/learning-logs/learning-log-[name].md`
```

## Naming

Every agent gets a human name. The name goes first in the title (`# Name — Role`), in the identity section, and in the "Just say" examples. This lets the user call agents by name: "Hey [Name], [do X]"

File naming: `agents/[name]-[role].md` (e.g., `agents/martha-chief-of-staff.md`)

## Guidelines

- **Identity first.** The agent should know who it is before it knows what to do.
- **Second person.** Write as "You are [Name]..." — these are instructions to Claude about who to be.
- **"Just say" examples.** Include the agent's name. Teach the user how to talk to the agent.
- **Explicit boundaries.** What the agent does NOT do prevents scope creep.
