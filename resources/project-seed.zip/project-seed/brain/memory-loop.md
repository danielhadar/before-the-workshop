# Memory Loop

## What to Check

After significant work, before moving on:
- New insight? → Update your log in `brain/learning-logs/`
- Noteworthy decision? → Update `brain/decisions.md`
- Project scope/goals changed? → Update `core/project-brief.md` (rare)
- User preferences changed? → Update `core/user-identity.md` (rare)
- Brand voice evolved? → Update `core/tone-of-voice.md` (rare)
- Produced something reusable? → Save in `brain/artifacts/`

## How to Write a Learning Log Entry

- What worked that we should repeat?
- What failed that we should avoid?
- Any pattern emerging?

## How to Write a Decision Entry

- What was decided?
- Why?
- What alternatives did we reject, and why?
