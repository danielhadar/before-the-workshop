# Decisions

Standing decisions and choices. Updated by the Chief of Staff after noteworthy decisions.

---

*No decisions recorded yet.*
